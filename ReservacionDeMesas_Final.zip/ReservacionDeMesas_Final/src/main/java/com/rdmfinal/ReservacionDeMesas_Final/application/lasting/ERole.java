package com.rdmfinal.ReservacionDeMesas_Final.application.lasting;

public enum ERole {
  USER,
  ADMIN
}
