package com.rdmfinal.ReservacionDeMesas_Final.domain.dto;

public record AuthenticationDto(
  String email,
  String password
) {
}
