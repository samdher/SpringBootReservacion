package com.rdmfinal.ReservacionDeMesas_Final;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservacionDeMesasFinalApplication {

	public static void main(String[] args) {

		SpringApplication.run(ReservacionDeMesasFinalApplication.class, args);

	}
}
