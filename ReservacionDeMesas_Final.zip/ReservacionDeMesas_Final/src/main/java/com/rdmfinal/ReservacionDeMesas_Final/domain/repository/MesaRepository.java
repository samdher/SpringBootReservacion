package com.rdmfinal.ReservacionDeMesas_Final.domain.repository;

import com.rdmfinal.ReservacionDeMesas_Final.domain.entity.Mesa;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MesaRepository extends JpaRepository<Mesa, Long> {

}
